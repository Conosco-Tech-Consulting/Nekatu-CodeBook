To set up the audit template.

In the scanner folder run config.bat either via cmd or straight by double clicking and go through the EZ set up of basic setup and save the EZ file and leave it as audit.ezc to the scanner folder.

Edit the Start.bat script to point to your UNC path share
Edit the securitylow.vbs to point to your unc path of excel audit sheet.