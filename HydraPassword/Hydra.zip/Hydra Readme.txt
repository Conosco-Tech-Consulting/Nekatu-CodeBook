==============================================
Hydra Password Script
Copyright (c) Arik Fletcher
==============================================
Script:	  	hydra.cmd
Created:	11/03/2008
Modified:	11/03/2008
Version:	1.0
Author:	  	Arik Fletcher
--------------------------------------------

The �hydra script� has been developed to 
reset the local admin password to one of ten
pre-determined values at system start up.

This allows an IT team to provide a user with
a one-off password based on a shared secret
stored in the "Admin Access" subfolder in the
All Users' Start Menu\Programs folder. 

Users can then make a required change with the
password being automatically reset at reboot.

--------------------------------------------